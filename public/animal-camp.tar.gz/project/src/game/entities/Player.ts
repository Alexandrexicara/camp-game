import * as Phaser from 'phaser';
import { UnifiedInput } from '@/kit/input';
import { useGameStore } from '@/store/useGameStore';
import { PLAYER } from '../config';

export class Player extends Phaser.GameObjects.Sprite {
  declare body: Phaser.Physics.Arcade.Body;

  // renamed to avoid conflict with Phaser's internal `input` property
  private gameInput: UnifiedInput;
  private isInvincible = false;
  private jumpCount = 0;
  private maxJumps = 2;
  private facingRight = true;

  constructor(scene: Phaser.Scene, x: number, y: number) {
    const textureKey = scene.textures.exists('raccoon_idle') ? 'raccoon_idle' : 'raccoon_run';
    super(scene, x, y, textureKey, 0);

    scene.add.existing(this);
    scene.physics.add.existing(this as unknown as Phaser.GameObjects.GameObject, false);

    this.gameInput = new UnifiedInput(scene);

    this.setDisplaySize(48, 48);
    this.setDepth(10);

    const body = this.body as Phaser.Physics.Arcade.Body;
    body.setSize(28, 44);
    body.setOffset((64 - 28) / 2, 64 - 44);
    body.setCollideWorldBounds(true);
    body.setMaxVelocityX(PLAYER.speed * 1.5);
    body.setMaxVelocityY(700);
    body.setGravityY(0);

    if (scene.anims.exists('raccoon_idle_anim')) {
      this.play('raccoon_idle_anim');
    }
  }

  update() {
    const body = this.body as Phaser.Physics.Arcade.Body;
    const { left, right, jumpJustPressed } = this.gameInput;

    // Reset jump count on landing
    if (body.blocked.down) {
      this.jumpCount = 0;
    }

    // Horizontal movement
    if (left) {
      body.setVelocityX(-PLAYER.speed);
      this.facingRight = false;
      this.setFlipX(true);
    } else if (right) {
      body.setVelocityX(PLAYER.speed);
      this.facingRight = true;
      this.setFlipX(false);
    } else {
      body.setVelocityX(0);
    }

    // Jump (double jump allowed)
    if (jumpJustPressed && this.jumpCount < this.maxJumps) {
      body.setVelocityY(PLAYER.jumpVelocity);
      this.jumpCount++;
      try { (this.scene as any).audio?.play('jump'); } catch { /* synth fallback */ }
    }

    // Animate
    this.updateAnimation(body);
  }

  private updateAnimation(body: Phaser.Physics.Arcade.Body) {
    const movingX = Math.abs(body.velocity.x) > 10;

    if (!body.blocked.down) {
      if (this.scene.textures.exists('raccoon_jump')) {
        if (this.anims.isPlaying) this.stop();
        this.setTexture('raccoon_jump', 0);
      }
    } else if (movingX) {
      if (this.scene.anims.exists('raccoon_run_anim') && this.anims.currentAnim?.key !== 'raccoon_run_anim') {
        this.play('raccoon_run_anim');
      }
    } else {
      if (this.scene.anims.exists('raccoon_idle_anim') && this.anims.currentAnim?.key !== 'raccoon_idle_anim') {
        this.play('raccoon_idle_anim');
      }
    }
  }

  hit() {
    if (this.isInvincible) return;
    this.isInvincible = true;
    useGameStore.getState().loseLife();
    try { (this.scene as any).audio?.play('hurt'); } catch { /* no-op */ }

    // Flash invincibility
    this.scene.tweens.add({
      targets: this,
      alpha: 0.3,
      duration: 120,
      yoyo: true,
      repeat: 8,
      onComplete: () => {
        this.alpha = 1;
        this.isInvincible = false;
      },
    });

    // Knockback
    const body = this.body as Phaser.Physics.Arcade.Body;
    body.setVelocityY(-300);
    body.setVelocityX(this.facingRight ? -160 : 160);
  }

  stomp(): void {
    const body = this.body as Phaser.Physics.Arcade.Body;
    body.setVelocityY(-300);
  }
}
