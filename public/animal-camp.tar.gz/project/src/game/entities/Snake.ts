import * as Phaser from 'phaser';
import { Enemy } from './Enemy';

/** Snake — slithers on the ground, low profile, hard to stomp */
export class Snake extends Enemy {
  private direction = 1;
  private speed: number;
  private patrolLeft: number;
  private patrolRight: number;
  private strikeTimer = 0;

  constructor(scene: Phaser.Scene, x: number, y: number, patrolLeft: number, patrolRight: number, speed = 80) {
    Snake.ensureTexture(scene);
    super(scene, x, y, 'enemy_snake', 0);
    this.patrolLeft = patrolLeft;
    this.patrolRight = patrolRight;
    this.speed = speed;
    this.setDisplaySize(56, 24);

    const body = this.body as Phaser.Physics.Arcade.Body;
    body.setSize(48, 16);
    body.setOffset(4, 8);
    body.setCollideWorldBounds(true);
    body.setGravityY(0);
    body.setMaxVelocityY(50);

    if (scene.anims.exists('snake_slither_anim')) this.play('snake_slither_anim');
  }

  update(time: number) {
    if (this.dead) return;
    const body = this.body as Phaser.Physics.Arcade.Body;

    // Slither
    if (time > this.strikeTimer) {
      body.setVelocityX(this.direction * this.speed);
    }
    if (this.x <= this.patrolLeft) { this.direction = 1; this.setFlipX(false); }
    else if (this.x >= this.patrolRight) { this.direction = -1; this.setFlipX(true); }
  }

  private static ensureTexture(scene: Phaser.Scene) {
    if (scene.textures.exists('enemy_snake')) return;
    const g = scene.add.graphics();
    // 4 frames: wave animation
    for (let f = 0; f < 4; f++) {
      const ox = f * 64;
      const wave = Math.sin(f * Math.PI / 2);
      // body segments (green with pattern)
      for (let s = 0; s < 5; s++) {
        const sx = ox + 8 + s * 10;
        const sy = 14 + Math.sin((s + f) * 0.8) * 4;
        g.fillStyle(s % 2 === 0 ? 0x2eb82e : 0x1a991a, 1);
        g.fillEllipse(sx, sy, 14, 12);
      }
      // diamonds pattern
      g.fillStyle(0x006600, 0.7);
      for (let s = 0; s < 5; s++) {
        const sx = ox + 12 + s * 10;
        const sy = 14 + Math.sin((s + f) * 0.8) * 4;
        g.fillRect(sx - 2, sy - 3, 5, 6);
      }
      // head
      g.fillStyle(0x1aaa1a, 1); g.fillEllipse(ox + 58, 14 + wave * 2, 18, 14);
      // eyes
      g.fillStyle(0xff0000, 1); g.fillCircle(ox + 62, 11, 2.5);
      // tongue
      g.fillStyle(0xff3333, 1); g.fillRect(ox + 64, 15, 6, 1); g.fillRect(ox + 68, 13, 2, 1); g.fillRect(ox + 68, 17, 2, 1);
      // rattle tail
      g.fillStyle(0xaa8800, 1); g.fillEllipse(ox + 8, 14, 8, 8); g.fillEllipse(ox + 4, 14, 6, 6);
    }
    g.generateTexture('enemy_snake', 256, 28);
    g.destroy();
    const tex = scene.textures.get('enemy_snake');
    for (let i = 0; i < 4; i++) tex.add(i, 0, i * 64, 0, 64, 28);
    if (!scene.anims.exists('snake_slither_anim')) {
      scene.anims.create({ key: 'snake_slither_anim', frames: scene.anims.generateFrameNumbers('enemy_snake', { start: 0, end: 3 }), frameRate: 6, repeat: -1 });
    }
  }
}
