import * as Phaser from 'phaser';
import { Enemy } from './Enemy';

/** Jaguar — runs fast on the ground, turns at patrol edges */
export class Jaguar extends Enemy {
  private direction = 1;
  private speed: number;
  private patrolLeft: number;
  private patrolRight: number;

  constructor(scene: Phaser.Scene, x: number, y: number, patrolLeft: number, patrolRight: number, speed = 130) {
    Jaguar.ensureTexture(scene);
    super(scene, x, y, 'enemy_jaguar', 0);
    this.patrolLeft = patrolLeft;
    this.patrolRight = patrolRight;
    this.speed = speed;
    this.setDisplaySize(48, 40);

    const body = this.body as Phaser.Physics.Arcade.Body;
    body.setSize(40, 32);
    body.setOffset(4, 8);
    body.setCollideWorldBounds(true);
    body.setGravityY(0);

    if (scene.anims.exists('jaguar_run_anim')) {
      this.play('jaguar_run_anim');
    }
  }

  update(_time: number) {
    if (this.dead) return;
    const body = this.body as Phaser.Physics.Arcade.Body;
    body.setVelocityX(this.direction * this.speed);
    if (this.x <= this.patrolLeft) { this.direction = 1; this.setFlipX(false); }
    else if (this.x >= this.patrolRight) { this.direction = -1; this.setFlipX(true); }
  }

  private static ensureTexture(scene: Phaser.Scene) {
    if (scene.textures.exists('enemy_jaguar')) return;
    const g = scene.add.graphics();
    // 2 frames: run stride
    for (let f = 0; f < 4; f++) {
      const ox = f * 48;
      const legAlt = f % 2 === 0;
      // body (golden yellow with spots)
      g.fillStyle(0xe8a020, 1); g.fillRoundedRect(ox + 6, 8, 36, 24, 6);
      // head
      g.fillStyle(0xe8a020, 1); g.fillCircle(ox + 38, 12, 12);
      // snout
      g.fillStyle(0xd08010, 1); g.fillEllipse(ox + 47, 14, 10, 7);
      // eyes
      g.fillStyle(0x220000, 1); g.fillCircle(ox + 40, 10, 2.5);
      // ears
      g.fillStyle(0xe8a020, 1); g.fillTriangle(ox+32,2, ox+28,10, ox+36,10);
      g.fillTriangle(ox+44,2, ox+40,10, ox+48,10);
      // spots
      g.fillStyle(0x8b4000, 0.6);
      g.fillCircle(ox + 14, 14, 4); g.fillCircle(ox + 24, 18, 3); g.fillCircle(ox + 20, 10, 3);
      // tail
      g.fillStyle(0xe8a020, 1); g.fillEllipse(ox + 4, 16, 10, 6);
      // legs
      g.fillStyle(0xd08010, 1);
      g.fillRect(ox + (legAlt ? 10 : 14), 28, 8, 12);
      g.fillRect(ox + (legAlt ? 28 : 24), 28, 8, 12);
      // paws
      g.fillStyle(0xc07010, 1);
      g.fillEllipse(ox + (legAlt ? 14 : 18), 40, 10, 5);
      g.fillEllipse(ox + (legAlt ? 32 : 28), 40, 10, 5);
    }
    g.generateTexture('enemy_jaguar', 192, 48);
    g.destroy();
    const tex = scene.textures.get('enemy_jaguar');
    for (let i = 0; i < 4; i++) tex.add(i, 0, i * 48, 0, 48, 48);
    if (!scene.anims.exists('jaguar_run_anim')) {
      scene.anims.create({ key: 'jaguar_run_anim', frames: scene.anims.generateFrameNumbers('enemy_jaguar', { start: 0, end: 3 }), frameRate: 8, repeat: -1 });
    }
  }
}
