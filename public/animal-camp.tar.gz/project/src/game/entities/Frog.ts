import * as Phaser from 'phaser';
import { Enemy } from './Enemy';

export class Frog extends Enemy {
  private direction = 1;
  private hopTimer = 0;
  private hopInterval: number;
  private patrolLeft: number;
  private patrolRight: number;

  constructor(scene: Phaser.Scene, x: number, y: number, patrolLeft: number, patrolRight: number, hopInterval = 1800) {
    super(scene, x, y, 'frog_hop', 0);
    this.patrolLeft = patrolLeft;
    this.patrolRight = patrolRight;
    this.hopInterval = hopInterval;
    this.setDisplaySize(36, 36);

    const body = this.body as Phaser.Physics.Arcade.Body;
    body.setSize(28, 26);
    body.setOffset((48 - 28) / 2, 48 - 26);
    body.setCollideWorldBounds(true);
    body.setGravityY(0);

    if (scene.anims.exists('frog_hop_anim')) this.play('frog_hop_anim');
  }

  update(time: number) {
    if (this.dead) return;
    const body = this.body as Phaser.Physics.Arcade.Body;
    if (time > this.hopTimer) {
      this.hopTimer = time + this.hopInterval;
      body.setVelocityX(this.direction * 110);
      body.setVelocityY(-300);
    }
    if (this.x <= this.patrolLeft) { this.direction = 1; this.setFlipX(false); }
    else if (this.x >= this.patrolRight) { this.direction = -1; this.setFlipX(true); }
    if (body.blocked.down) body.setVelocityX(body.velocity.x * 0.75);
  }
}
