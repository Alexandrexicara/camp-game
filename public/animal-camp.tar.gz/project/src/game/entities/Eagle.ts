import * as Phaser from 'phaser';
import { Enemy } from './Enemy';

/** Eagle — flies horizontally, swoops down when player is below */
export class Eagle extends Enemy {
  private baseY: number;
  private speed: number;
  private patrolLeft: number;
  private patrolRight: number;
  private direction = 1;
  private swooping = false;
  private swoopCooldown = 0;

  constructor(scene: Phaser.Scene, x: number, y: number, patrolLeft: number, patrolRight: number, speed = 110) {
    Eagle.ensureTexture(scene);
    super(scene, x, y, 'enemy_eagle', 0);
    this.baseY = y;
    this.patrolLeft = patrolLeft;
    this.patrolRight = patrolRight;
    this.speed = speed;
    this.setDisplaySize(50, 38);

    const body = this.body as Phaser.Physics.Arcade.Body;
    body.setSize(40, 28);
    body.setOffset(5, 5);
    body.setAllowGravity(false);
    body.setCollideWorldBounds(false);

    if (scene.anims.exists('eagle_fly_anim')) this.play('eagle_fly_anim');
  }

  update(time: number, _px?: number, playerY?: number) {
    if (this.dead) return;
    const body = this.body as Phaser.Physics.Arcade.Body;

    // Patrol
    body.setVelocityX(this.direction * this.speed);
    if (this.x <= this.patrolLeft) { this.direction = 1; this.setFlipX(true); }
    else if (this.x >= this.patrolRight) { this.direction = -1; this.setFlipX(false); }

    // Swoop: dive toward player when close enough vertically
    if (!this.swooping && time > this.swoopCooldown && playerY !== undefined && playerY > this.baseY) {
      this.swooping = true;
    }
    if (this.swooping) {
      body.setVelocityY(200);
      if (this.y > this.baseY + 120) {
        this.swooping = false;
        this.swoopCooldown = time + 2000;
      }
    } else {
      // Return to base height
      const dy = this.baseY - this.y;
      body.setVelocityY(dy > 0 ? Math.min(dy * 2, 80) : Math.max(dy * 2, -80));
    }
  }

  private static ensureTexture(scene: Phaser.Scene) {
    if (scene.textures.exists('enemy_eagle')) return;
    const g = scene.add.graphics();
    for (let f = 0; f < 2; f++) {
      const ox = f * 56;
      const wingUp = f === 0;
      // body
      g.fillStyle(0x6b3a10, 1); g.fillEllipse(ox + 28, 20, 32, 22);
      // white head
      g.fillStyle(0xffffff, 1); g.fillCircle(ox + 46, 14, 10);
      // beak
      g.fillStyle(0xffcc00, 1); g.fillTriangle(ox + 54, 14, ox + 62, 16, ox + 54, 18);
      // eye
      g.fillStyle(0x111111, 1); g.fillCircle(ox + 48, 13, 2.5);
      g.fillStyle(0xffff00, 0.6); g.fillCircle(ox + 48, 13, 1.5);
      // wings
      g.fillStyle(0x4a2808, 1);
      if (wingUp) {
        g.fillTriangle(ox + 16, 14, ox + 0, 2, ox + 28, 20);
        g.fillTriangle(ox + 28, 20, ox + 56, 2, ox + 44, 26);
      } else {
        g.fillTriangle(ox + 16, 22, ox + 0, 36, ox + 28, 20);
        g.fillTriangle(ox + 28, 20, ox + 56, 36, ox + 44, 18);
      }
      // tail
      g.fillStyle(0x6b3a10, 1); g.fillTriangle(ox + 8, 18, ox + 0, 22, ox + 10, 26);
      // talons
      g.fillStyle(0xffcc00, 1); g.fillRect(ox + 20, 30, 4, 6); g.fillRect(ox + 26, 30, 4, 6);
    }
    g.generateTexture('enemy_eagle', 112, 40);
    g.destroy();
    const tex = scene.textures.get('enemy_eagle');
    for (let i = 0; i < 2; i++) tex.add(i, 0, i * 56, 0, 56, 40);
    if (!scene.anims.exists('eagle_fly_anim')) {
      scene.anims.create({ key: 'eagle_fly_anim', frames: scene.anims.generateFrameNumbers('enemy_eagle', { start: 0, end: 1 }), frameRate: 5, repeat: -1 });
    }
  }
}
