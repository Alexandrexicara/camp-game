import * as Phaser from 'phaser';
import { Enemy } from './Enemy';

/** Caiman — slow, heavy, can't be stomped (too hard). Must be avoided. */
export class Caiman extends Enemy {
  private direction = 1;
  private speed: number;
  private patrolLeft: number;
  private patrolRight: number;
  private snapTimer = 0;
  readonly cannotBeStomp = true; // Player bounces off but takes damage

  constructor(scene: Phaser.Scene, x: number, y: number, patrolLeft: number, patrolRight: number, speed = 55) {
    Caiman.ensureTexture(scene);
    super(scene, x, y, 'enemy_caiman', 0);
    this.patrolLeft = patrolLeft;
    this.patrolRight = patrolRight;
    this.speed = speed;
    this.setDisplaySize(64, 32);

    const body = this.body as Phaser.Physics.Arcade.Body;
    body.setSize(56, 22);
    body.setOffset(4, 10);
    body.setCollideWorldBounds(true);
    body.setGravityY(0);

    if (scene.anims.exists('caiman_walk_anim')) this.play('caiman_walk_anim');
  }

  update(time: number) {
    if (this.dead) return;
    const body = this.body as Phaser.Physics.Arcade.Body;
    body.setVelocityX(this.direction * this.speed);
    if (this.x <= this.patrolLeft) { this.direction = 1; this.setFlipX(false); }
    else if (this.x >= this.patrolRight) { this.direction = -1; this.setFlipX(true); }

    // Snap: briefly stop and snap jaw open
    if (time > this.snapTimer) {
      this.snapTimer = time + 3000 + Math.random() * 2000;
      body.setVelocityX(0);
      this.scene.time.delayedCall(600, () => {
        if (!this.dead) body.setVelocityX(this.direction * this.speed);
      });
    }
  }

  stomp() {
    // Cannot be stomped — just bounce player back
    return;
  }

  private static ensureTexture(scene: Phaser.Scene) {
    if (scene.textures.exists('enemy_caiman')) return;
    const g = scene.add.graphics();
    for (let f = 0; f < 2; f++) {
      const ox = f * 72;
      const legOff = f === 0 ? 0 : 3;
      // body (dark green armored)
      g.fillStyle(0x1a6b1a, 1); g.fillRoundedRect(ox + 4, 10, 52, 20, 5);
      // scales / ridges
      g.fillStyle(0x0d4d0d, 0.7);
      for (let r = 0; r < 6; r++) g.fillRect(ox + 6 + r * 8, 12, 5, 4);
      // head with open jaw
      g.fillStyle(0x1a6b1a, 1); g.fillRoundedRect(ox + 50, 8, 20, 16, 4);
      // jaw
      g.fillStyle(0x0d4d0d, 1); g.fillRect(ox + 52, 20, 18, 4);
      // teeth
      g.fillStyle(0xffffff, 1);
      for (let t = 0; t < 4; t++) { g.fillRect(ox + 54 + t * 4, 18, 2, 4); g.fillRect(ox + 54 + t * 4, 24, 2, 3); }
      // eyes (on top of head, bulging)
      g.fillStyle(0xffff00, 1); g.fillCircle(ox + 54, 9, 4);
      g.fillStyle(0x111111, 1); g.fillCircle(ox + 54, 9, 2);
      // legs
      g.fillStyle(0x155a15, 1);
      g.fillRect(ox + 14 + legOff, 28, 8, 10); g.fillRect(ox + 30 - legOff, 28, 8, 10);
      // tail
      g.fillStyle(0x155a15, 1); g.fillTriangle(ox + 4, 16, ox + 0, 12, ox + 0, 22);
    }
    g.generateTexture('enemy_caiman', 144, 40);
    g.destroy();
    const tex = scene.textures.get('enemy_caiman');
    for (let i = 0; i < 2; i++) tex.add(i, 0, i * 72, 0, 72, 40);
    if (!scene.anims.exists('caiman_walk_anim')) {
      scene.anims.create({ key: 'caiman_walk_anim', frames: scene.anims.generateFrameNumbers('enemy_caiman', { start: 0, end: 1 }), frameRate: 3, repeat: -1 });
    }
  }
}
